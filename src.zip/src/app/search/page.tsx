import { Metadata } from 'next';
import { supabaseService } from '@/services/supabaseService';
import SearchPageClient from './client';
import { Property } from '@/types';

export const metadata: Metadata = {
  title: 'بحث عن عقارات في جمصة - ابحث بالسعر، المنطقة، والمساحة',
  description:
    'ابحث عن شاليهات، فيلات، وشقق للإيجار في جمصة. فلتر حسب السعر، عدد الغرف، والموقع. احجز عقارك المثالي.',
  keywords: ['بحث عقارات جمصة', 'بحث شاليهات', 'فلتر عقارات', 'إيجار جمصة', 'بحث بالإيجار'],
};

async function getInitialProperties(searchParams: {
  q?: string;
  category?: string;
  minPrice?: string;
  maxPrice?: string;
  bedrooms?: string;
  bathrooms?: string;
  area?: string;
  features?: string;
  page?: string;
}): Promise<{ properties: Property[]; hasMore: boolean }> {
  try {
    const PAGE_SIZE = 12;
    const page = Math.max(1, Number(searchParams.page || '1') || 1);
    const offset = (page - 1) * PAGE_SIZE;

    const filters: any = { status: 'available' };

    if (searchParams.category && searchParams.category !== 'all') filters.category = searchParams.category;
    if (searchParams.minPrice) filters.minPrice = Number(searchParams.minPrice);
    if (searchParams.maxPrice) filters.maxPrice = Number(searchParams.maxPrice);
    if (searchParams.bedrooms) filters.bedrooms = Number(searchParams.bedrooms);
    if (searchParams.bathrooms) filters.bathrooms = Number(searchParams.bathrooms);

    if (searchParams.area && searchParams.area !== 'all' && searchParams.area !== 'الكل') {
      filters.area = searchParams.area;
    }

    if (searchParams.features) {
      filters.features = searchParams.features
        .split(',')
        .map((x) => x.trim())
        .filter(Boolean);
    }

    if (searchParams.q && searchParams.q.trim()) filters.q = searchParams.q.trim();

    const rows = await supabaseService.getProperties({
      ...filters,
      limit: PAGE_SIZE + 1,
      offset,
    });

    const hasMore = rows.length > PAGE_SIZE;
    const slice = hasMore ? rows.slice(0, PAGE_SIZE) : rows;

    const properties: Property[] = slice.map((row) => ({
      id: row.id,
      title: row.title,
      description: row.description || '',
      price: row.price,
      priceUnit: row.price_unit || 'day',
      category: row.category,
      status: row.status,
      images: row.images || [],
      location: {
        lat: row.location_lat || 0,
        lng: row.location_lng || 0,
        address: row.address || '',
        area: row.area || '',
      },
      ownerPhone: row.owner_phone || '',
      ownerId: row.owner_id,
      ownerName: row.owner_name || '',
      features: row.features || [],
      bedrooms: row.bedrooms || 1,
      bathrooms: row.bathrooms || 1,
      area: row.floor_area || 0,
      floor: row.floor_number || 1,
      isVerified: row.is_verified,
      viewsCount: row.views_count,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    }));

    return { properties, hasMore };
  } catch (error) {
    console.error('Failed to fetch initial properties:', error);
    return { properties: [], hasMore: false };
  }
}

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<{
    q?: string;
    category?: string;
    minPrice?: string;
    maxPrice?: string;
    bedrooms?: string;
    bathrooms?: string;
    area?: string;
    features?: string;
    page?: string;
  }>;
}) {
  const sp = await searchParams;
  const { properties: initialProperties, hasMore } = await getInitialProperties(sp);

  return (
    <SearchPageClient
      initialProperties={initialProperties}
      initialSearchParams={sp}
    />
  );
}
