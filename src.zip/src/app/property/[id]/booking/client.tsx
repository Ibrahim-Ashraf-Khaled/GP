'use client';

import React, { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { useAuth } from '@/context/AuthContext';
import { supabaseService } from '@/services/supabaseService';
import { PropertyRow } from '@/services/supabaseService';
import { RentalConfig, RentalType } from '@/types';
import DateSelector from '@/components/booking/DateSelector';
import TenantForm from '@/components/booking/TenantForm';
import PaymentMethods from '@/components/booking/PaymentMethods';
import PriceBreakdown from '@/components/booking/PriceBreakdown';
import Image from 'next/image';
import Link from 'next/link';

interface BookingPageClientProps {
  propertyId: string;
  initialProperty: PropertyRow;
}

export default function BookingPageClient({ propertyId, initialProperty }: BookingPageClientProps) {
  const router = useRouter();
  const { user, loading: authLoading } = useAuth();
  const errorRef = useRef<HTMLDivElement>(null);

  // Property state
  const [property] = useState<PropertyRow>(initialProperty);

  // Stepper state
  const [currentStep, setCurrentStep] = useState<1 | 2 | 3>(1);
  const totalSteps = 3;

  // Date state
  const [startDate, setStartDate] = useState<Date | null>(null);
  const [endDate, setEndDate] = useState<Date | null>(null);
  const [availabilityStatus, setAvailabilityStatus] = useState<'idle' | 'checking' | 'available' | 'unavailable' | 'error'>('idle');

  // Tenant data state
  const [tenantName, setTenantName] = useState('');
  const [tenantPhone, setTenantPhone] = useState('');
  const [tenantEmail, setTenantEmail] = useState('');

  // Payment method state
  const [paymentMethod, setPaymentMethod] = useState<'vodafone_cash' | 'instapay' | 'cash_on_delivery' | null>(null);

  // Price calculation state
  const [priceDetails, setPriceDetails] = useState({
    basePrice: 0,
    serviceFee: 0,
    depositAmount: 0,
    totalAmount: 0,
    duration: 0
  });

  // Form submission state
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [rentalConfig] = useState<RentalConfig>({
    type: 'daily' as RentalType, // default, should ideally come from property properties if available
    pricePerUnit: property.price,
    minDuration: 1,
    maxDuration: 30,
  });

  // Pre-fill user data
  useEffect(() => {
    if (user) {
      setTenantName(user.name || user.email?.split('@')[0] || '');
      setTenantEmail(user.email || '');
      if (user.phone) setTenantPhone(user.phone);
    }
  }, [user]);

  // Handle Price Calculations
  useEffect(() => {
    if (startDate && endDate) {
      const details = supabaseService.calculateTotalPrice(
        rentalConfig,
        startDate,
        endDate
      );
      setPriceDetails(details);
    } else {
      setPriceDetails({
        basePrice: 0,
        serviceFee: 0,
        depositAmount: 0,
        totalAmount: 0,
        duration: 0
      });
      setAvailabilityStatus('idle');
    }
  }, [startDate, endDate, rentalConfig]);

  // Handle Availability Check automatically when dates change
  useEffect(() => {
    let isMounted = true;
    const checkCurrentDates = async () => {
      if (!startDate || !endDate) return;

      setAvailabilityStatus('checking');
      setError(null);

      const { available, error } = await supabaseService.checkAvailability(
        propertyId,
        startDate.toISOString().split('T')[0],
        endDate.toISOString().split('T')[0]
      );

      if (!isMounted) return;

      if (error) {
        console.error('Availability check failed:', error);
        setAvailabilityStatus('error');
      } else {
        setAvailabilityStatus(available ? 'available' : 'unavailable');
      }
    };

    const debounceTimer = setTimeout(checkCurrentDates, 500);
    return () => {
      isMounted = false;
      clearTimeout(debounceTimer);
    };
  }, [startDate, endDate, propertyId]);

  const scrollToError = () => {
    if (errorRef.current) {
      errorRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const validateCurrentStep = () => {
    setError(null);
    if (currentStep === 1) {
      if (!startDate || !endDate) {
        setError('يرجى اختيار تاريخ البداية والنهاية أولاً');
        scrollToError();
        return false;
      }
      if (availabilityStatus !== 'available') {
        setError('يرجى اختيار تواريخ متاحة');
        scrollToError();
        return false;
      }
    } else if (currentStep === 2) {
      if (!tenantName.trim()) {
        setError('يرجى إدخال الاسم الكامل');
        scrollToError();
        return false;
      }
      const phoneRegex = /^01[0-9]{9}$/;
      if (!phoneRegex.test(tenantPhone)) {
        setError('يرجى إدخال رقم هاتف مصري صحيح (مثال: 01012345678)');
        scrollToError();
        return false;
      }
    }
    return true;
  };

  const handleNextStep = () => {
    if (validateCurrentStep()) {
      setCurrentStep(prev => Math.min(prev + 1, totalSteps) as 1 | 2 | 3);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handlePrevStep = () => {
    setError(null);
    setCurrentStep(prev => Math.max(prev - 1, 1) as 1 | 2 | 3);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setError(null);

    if (!validateCurrentStep()) return;

    if (!paymentMethod) {
      setError('يرجى اختيار طريقة الدفع لإتمام الحجز');
      scrollToError();
      return;
    }

    if (!user || !user.id || user.id === 'guest') {
      setError('خطأ في مصادقة المستخدم، يرجى تسجيل الدخول مجدداً');
      scrollToError();
      return;
    }

    setIsSubmitting(true);

    try {
      const { data: booking, error: bookingError } = await supabaseService.createBooking({
        propertyId,
        userId: user.id,
        startDate: startDate!.toISOString(),
        endDate: endDate!.toISOString(),
        totalNights: priceDetails.duration,
        totalMonths: Math.ceil(priceDetails.duration / 30),
        rentalType: rentalConfig.type,
        tenantName,
        tenantPhone,
        tenantEmail,
        basePrice: priceDetails.basePrice,
        serviceFee: priceDetails.serviceFee,
        depositAmount: priceDetails.depositAmount,
        totalAmount: priceDetails.totalAmount,
        paymentMethod,
        paymentStatus: 'pending',
        status: 'pending',
      });

      if (bookingError) throw new Error(bookingError.message);
      if (!booking) throw new Error('فشل إنشاء الحجز');

      router.push(`/property/${propertyId}/booking/confirmation?bookingId=${booking.id}`);
    } catch (err: any) {
      setError(err.message || 'فشل إرسال طلب الحجز. يرجى المحاولة مرة أخرى.');
      scrollToError();
      setIsSubmitting(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  // Auth Guard
  if (!user) {
    return (
      <div className="min-h-[80vh] flex flex-col items-center justify-center p-4 bg-gray-50 rtl">
        <div className="bg-white rounded-3xl shadow-xl w-full max-w-md p-8 text-center border border-gray-100">
          <div className="w-20 h-20 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-6">
            <span className="material-symbols-outlined text-4xl">lock</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-3">يجب تسجيل الدخول</h2>
          <p className="text-gray-500 mb-8 leading-relaxed">
            لإتمام عملية الحجز ومتابعة حالة طلبك، يرجى تسجيل الدخول إلى حسابك أو إنشاء حساب جديد.
          </p>
          <Link
            href={`/login?redirect=/property/${propertyId}/booking`}
            className="block w-full bg-blue-600 text-white font-semibold py-4 rounded-xl hover:bg-blue-700 transition-colors shadow-lg shadow-blue-600/20"
          >
            تسجيل الدخول / إنشاء حساب
          </Link>
          <button
            onClick={() => router.back()}
            className="block w-full mt-4 text-gray-500 font-medium py-3 hover:bg-gray-50 rounded-xl transition-colors"
          >
            العودة للعقار
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-36 lg:pb-12 rtl">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-5xl mx-auto px-4 py-4 flex items-center justify-between">
          <button
            onClick={() => router.back()}
            className="w-10 h-10 flex items-center justify-center rounded-full bg-gray-100 text-gray-600 hover:bg-gray-200 transition-colors"
          >
            <span className="material-symbols-outlined">arrow_forward</span>
          </button>
          <h1 className="text-lg font-bold text-gray-900">إتمام الحجز</h1>
          <div className="w-10"></div> {/* Spacer for centering */}
        </div>

        {/* Stepper Progress indicator */}
        <div className="max-w-md mx-auto px-4 pb-4">
          <div className="flex items-center justify-between relative">
            <div className="absolute left-0 right-0 top-1/2 h-1 bg-gray-200 -z-10 rounded-full transform -translate-y-1/2"></div>
            <div
              className="absolute right-0 top-1/2 h-1 bg-blue-600 -z-10 rounded-full transform -translate-y-1/2 transition-all duration-500 ease-out"
              style={{ width: `${((currentStep - 1) / (totalSteps - 1)) * 100}%` }}
            ></div>

            {[1, 2, 3].map((step) => (
              <div
                key={step}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-bold transition-colors duration-300 border-2
                            ${currentStep > step ? 'bg-blue-600 border-blue-600 text-white' :
                    currentStep === step ? 'bg-white border-blue-600 text-blue-600' :
                      'bg-white border-gray-300 text-gray-400'}`}
              >
                {currentStep > step ? <span className="material-symbols-outlined text-sm">check</span> : step}
              </div>
            ))}
          </div>
          <div className="flex justify-between mt-2 text-xs font-medium text-gray-500 px-1">
            <span className={currentStep >= 1 ? 'text-blue-600' : ''}>التواريخ</span>
            <span className={currentStep >= 2 ? 'text-blue-600' : ''}>البيانات</span>
            <span className={currentStep >= 3 ? 'text-blue-600' : ''}>الدفع</span>
          </div>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-6 md:py-8 lg:px-8">
        {/* Breadcrumb Navigation */}
        <nav className="text-xs font-bold text-gray-400 flex items-center gap-2 mb-6">
          <Link className="hover:text-blue-600 transition-colors" href="/">الرئيسية</Link>
          <span className="material-symbols-outlined text-[14px]">chevron_left</span>
          <span className="text-gray-600 dark:text-gray-300">إتمام الحجز</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10">

          {/* Main Content Area */}
          <div className="lg:col-span-7 space-y-6">

            {/* Step 1: Dates */}
            <div className={`${currentStep !== 1 ? 'hidden' : 'block'} animate-[fadeIn_0.4s_ease-out]`}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">اختر موعد الحجز</h2>
              </div>

              <div className="bg-white rounded-2xl p-1 shadow-sm border border-gray-100 mb-6">
                <DateSelector
                  startDate={startDate}
                  endDate={endDate}
                  onStartDateChange={setStartDate}
                  onEndDateChange={setEndDate}
                  rentalConfig={rentalConfig}
                />

                {/* Availability Status Banner */}
                {(startDate && endDate) && (
                  <div className="px-4 pb-4">
                    {availabilityStatus === 'checking' && (
                      <div className="bg-blue-50 text-blue-700 p-4 rounded-xl flex items-center gap-3">
                        <div className="w-5 h-5 border-2 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
                        <span className="font-medium">جاري التحقق من التوافر...</span>
                      </div>
                    )}
                    {availabilityStatus === 'available' && (
                      <div className="bg-emerald-50 text-emerald-700 border border-emerald-200 p-4 rounded-xl flex items-center gap-3">
                        <div className="w-8 h-8 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center shrink-0">
                          <span className="material-symbols-outlined text-lg">check_circle</span>
                        </div>
                        <div>
                          <div className="font-bold">العقار متاح!</div>
                          <div className="text-sm opacity-90">يمكنك الاستمرار لإتمام الحجز.</div>
                        </div>
                      </div>
                    )}
                    {availabilityStatus === 'unavailable' && (
                      <div className="bg-red-50 text-red-700 border border-red-200 p-4 rounded-xl flex items-center gap-3">
                        <div className="w-8 h-8 bg-red-100 text-red-600 rounded-full flex items-center justify-center shrink-0">
                          <span className="material-symbols-outlined text-lg">event_busy</span>
                        </div>
                        <div>
                          <div className="font-bold">العقار محجوز في هذه التواريخ</div>
                          <div className="text-sm opacity-90">يرجى اختيار تواريخ أخرى للمحاولة.</div>
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Step 2: Tenant Info */}
            <div className={`${currentStep !== 2 ? 'hidden' : 'block'} animate-[fadeIn_0.4s_ease-out]`}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">بيانات المستأجر</h2>
              </div>
              <TenantForm
                tenantName={tenantName}
                tenantPhone={tenantPhone}
                tenantEmail={tenantEmail}
                onNameChange={setTenantName}
                onPhoneChange={setTenantPhone}
                onEmailChange={setTenantEmail}
              />
            </div>

            {/* Step 3: Payment */}
            <div className={`${currentStep !== 3 ? 'hidden' : 'block'} animate-[fadeIn_0.4s_ease-out]`}>
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-gray-900">طريقة الدفع ومراجعة الحجز</h2>
              </div>
              <PaymentMethods
                selectedMethod={paymentMethod}
                onMethodChange={setPaymentMethod}
              />
            </div>

            {/* Error Message Display */}
            {error && (
              <div ref={errorRef} className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl flex gap-3 items-start animate-[shake_0.4s_ease-in-out]">
                <span className="material-symbols-outlined shrink-0 text-red-500">error</span>
                <p className="font-medium pt-0.5">{error}</p>
              </div>
            )}

            {/* Desktop Navigation Buttons */}
            <div className="hidden lg:flex items-center justify-between border-t border-gray-200 pt-6 mt-8">
              {currentStep > 1 ? (
                <button
                  type="button"
                  onClick={handlePrevStep}
                  className="px-6 py-3 font-semibold text-gray-600 bg-white border border-gray-300 rounded-xl hover:bg-gray-50 transition-colors"
                >
                  السابق
                </button>
              ) : <div></div>}

              {currentStep < 3 ? (
                <button
                  type="button"
                  onClick={handleNextStep}
                  className="px-8 py-3 font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 active:scale-95 transition-all shadow-md shadow-blue-600/20"
                >
                  التالي
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="px-8 py-3 font-bold text-white bg-blue-600 rounded-xl hover:bg-blue-700 active:scale-95 transition-all shadow-md shadow-blue-600/20 disabled:opacity-70 flex items-center justify-center min-w-[140px]"
                >
                  {isSubmitting ? (
                    <span className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                  ) : 'تأكيد الحجز'}
                </button>
              )}
            </div>

          </div>

          {/* Right Column - Property Summary & Price (Sticky on Desktop) */}
          <div className="lg:col-span-5 relative">
            <div className="lg:sticky lg:top-24 space-y-6">
              {/* Property Summary Widget */}
              <div className="bg-white rounded-2xl p-5 shadow-sm border border-gray-100 flex gap-4 items-center">
                {property.images && property.images.length > 0 ? (
                  <div className="w-24 h-24 rounded-xl overflow-hidden shrink-0 relative bg-gray-100">
                    <Image
                      src={property.images[0]}
                      alt={property.title}
                      fill
                      className="object-cover"
                      sizes="96px"
                    />
                  </div>
                ) : (
                  <div className="w-24 h-24 rounded-xl bg-gray-100 shrink-0 flex items-center justify-center shrink-0">
                    <span className="material-symbols-outlined text-gray-400 text-3xl">image</span>
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-blue-600 bg-blue-50 w-fit px-2 py-1 rounded-md mb-2">
                    {rentalConfig.type === 'daily' ? 'إيجار يومي' : rentalConfig.type === 'monthly' ? 'إيجار شهري' : 'إيجار موسمي'}
                  </div>
                  <h3 className="font-bold text-gray-900 truncate text-base leading-tight">
                    {property.title}
                  </h3>
                  <div className="flex items-center gap-1 text-sm text-gray-500 mt-2">
                    <span className="material-symbols-outlined text-[16px]">location_on</span>
                    <span className="truncate">{property.address || 'جمصة'}</span>
                  </div>
                </div>
              </div>

              {/* Price Breakdown */}
              {/* Shows always on Desktop, but on Mobile we also want to see the details if we need to */}
              <div className="hidden lg:block">
                <PriceBreakdown
                  rentalType={rentalConfig.type}
                  duration={priceDetails.duration}
                  pricePerUnit={rentalConfig.pricePerUnit}
                  basePrice={priceDetails.basePrice}
                  serviceFee={priceDetails.serviceFee}
                  depositAmount={priceDetails.depositAmount}
                  totalAmount={priceDetails.totalAmount}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Sticky CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-[0_-10px_40px_rgba(0,0,0,0.08)] z-50 lg:hidden safe-area-bottom">

        {/* Mobile Price Collapse Header */}
        {(startDate && endDate && priceDetails.totalAmount > 0) && (
          <div className="px-4 pt-3 pb-1 border-b border-gray-100 bg-white/95 backdrop-blur">
            <PriceBreakdown
              rentalType={rentalConfig.type}
              duration={priceDetails.duration}
              pricePerUnit={rentalConfig.pricePerUnit}
              basePrice={priceDetails.basePrice}
              serviceFee={priceDetails.serviceFee}
              depositAmount={priceDetails.depositAmount}
              totalAmount={priceDetails.totalAmount}
            />
          </div>
        )}

        <div className="p-4 flex gap-3">
          {currentStep > 1 && (
            <button
              type="button"
              onClick={handlePrevStep}
              className="w-14 h-14 flex-shrink-0 flex items-center justify-center bg-gray-100 text-gray-600 rounded-2xl active:bg-gray-200 transition-colors"
            >
              <span className="material-symbols-outlined text-xl">arrow_forward</span>
            </button>
          )}

          {currentStep < 3 ? (
            <button
              type="button"
              onClick={handleNextStep}
              className="flex-1 h-14 font-bold text-white bg-blue-600 rounded-2xl active:scale-95 transition-transform flex flex-col items-center justify-center shadow-lg shadow-blue-600/20"
            >
              <span className="text-lg">استمرار</span>
            </button>
          ) : (
            <button
              type="button"
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="flex-1 h-14 font-bold text-white bg-blue-600 rounded-2xl active:scale-95 transition-transform flex flex-col items-center justify-center shadow-lg shadow-blue-600/20 disabled:opacity-70"
            >
              {isSubmitting ? (
                <span className="w-6 h-6 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
              ) : (
                <span className="text-lg">تأكيد الحجز النهائي</span>
              )}
            </button>
          )}
        </div>
      </div>

      <style jsx>{`
        .safe-area-bottom {
            padding-bottom: env(safe-area-inset-bottom);
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            25% { transform: translateX(-5px); }
            50% { transform: translateX(5px); }
            75% { transform: translateX(-5px); }
        }
      `}</style>
    </div>
  );
}
