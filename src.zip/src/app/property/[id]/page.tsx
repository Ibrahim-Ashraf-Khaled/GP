import { Metadata } from 'next';
import { supabaseService } from '@/services/supabaseService';
import ClientPropertyDetails from './client';
import { notFound } from 'next/navigation';
import { Property, CATEGORY_AR } from '@/types';

// Fetch property data helper
async function getProperty(id: string): Promise<Property | null> {
    const propertyRow = await supabaseService.getPropertyById(id);

    if (!propertyRow) return null;

    // Map Supabase row to App Property type
    return {
        id: propertyRow.id,
        title: propertyRow.title,
        description: propertyRow.description || '',
        price: propertyRow.price,
        priceUnit: propertyRow.price_unit || 'day',
        category: propertyRow.category,
        status: propertyRow.status,
        images: propertyRow.images || [],
        location: {
            lat: propertyRow.location_lat || 0,
            lng: propertyRow.location_lng || 0,
            address: propertyRow.address || 'جمصة',
            area: propertyRow.area || '',
        },
        ownerPhone: propertyRow.owner_phone || '',
        ownerId: propertyRow.owner_id,
        ownerName: propertyRow.owner_name || 'مالك العقار',
        features: propertyRow.features || [],
        bedrooms: propertyRow.bedrooms || 1,
        bathrooms: propertyRow.bathrooms || 1,
        area: propertyRow.floor_area || 0,
        floor: propertyRow.floor_number || 1,
        isVerified: propertyRow.is_verified,
        viewsCount: propertyRow.views_count,
        createdAt: propertyRow.created_at,
        updatedAt: propertyRow.updated_at,
    };
}

export async function generateMetadata({ params }: { params: Promise<{ id: string }> }): Promise<Metadata> {
    const { id } = await params;
    const property = await getProperty(id);

    if (!property) {
        return {
            title: 'عقار غير موجود',
        };
    }

    const title = `${property.title} - ${property.price} ج.م | عقارات جمصة`;
    const description = `${CATEGORY_AR[property.category]} للإيجار في ${property.location.address}. ${property.bedrooms} غرف، ${property.bathrooms} حمام. ${property.description.substring(0, 100)}...`;

    const baseUrl = process.env.NEXT_PUBLIC_SITE_URL || 'https://gamasa-properties.vercel.app';

    return {
        title: title,
        description: description,
        alternates: {
            canonical: `${baseUrl}/property/${property.id}`,
        },
        openGraph: {
            title: title,
            description: description,
            images: property.images.length > 0 ? [property.images[0]] : [],
        },
        twitter: {
            card: 'summary_large_image',
            title: title,
            description: description,
            images: property.images.length > 0 ? [property.images[0]] : [],
        },
    };
}

import JsonLd from '@/components/JsonLd';

export default async function PropertyPage({ params }: { params: Promise<{ id: string }> }) {
    const { id } = await params;

    // Increase view count (Server Action style)
    await supabaseService.incrementPropertyViews(id);

    const property = await getProperty(id);

    if (!property) {
        notFound();
    }

    const listingData = {
        "@context": "https://schema.org",
        "@type": "RealEstateListing",
        "name": property.title,
        "description": property.description,
        "url": `https://gamasa-properties.vercel.app/property/${property.id}`,
        "image": property.images,
        "datePosted": property.createdAt,
        "address": {
            "@type": "PostalAddress",
            "addressLocality": property.location.area,
            "addressRegion": "جمصة",
            "addressCountry": "EG"
        },
        "offers": {
            "@type": "Offer",
            "price": property.price,
            "priceCurrency": "EGP",
            "availability": "https://schema.org/InStock"
        }
    };

    return (
        <>
            <JsonLd data={listingData} />
            <ClientPropertyDetails initialProperty={property} />
        </>
    );
}
