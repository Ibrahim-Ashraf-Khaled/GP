'use client';

import React from 'react';
import Image from 'next/image';

type PaymentMethod = 'vodafone_cash' | 'instapay' | 'cash_on_delivery';

interface PaymentMethodsProps {
    selectedMethod: PaymentMethod | null;
    onMethodChange: (method: PaymentMethod) => void;
}

export default function PaymentMethods({ selectedMethod, onMethodChange }: PaymentMethodsProps) {
    const paymentOptions: { value: PaymentMethod; label: string; icon: React.ReactNode; description: string; instruction: string }[] = [
        {
            value: 'vodafone_cash',
            label: 'محفظة فودافون كاش',
            icon: (
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8">
                    <path d="M12 0C5.373 0 0 5.373 0 12s5.373 12 12 12 12-5.373 12-12S18.627 0 12 0zm1.75 18.239c-3.18 0-4.06-3.38-4.06-3.38v-1.37h1.02s1 2.02 3.25 1.99c1.13.01 2.04-.79 2.08-1.94.04-.89-.64-1.57-1.49-1.57-.68 0-1.16.49-1.16 1.07 0 .5.38 1.05.88 1.05.11 0 .21-.02.32-.06-.3-1.02-1.28-1.76-2.39-1.74-1.39.03-2.61.94-2.88 2.3-.27 1.34.42 2.68 1.63 3.12 1.25.46 2.65-.25 3.16-1.46.52-1.24.08-2.68-1.03-3.32-1.18-.68-2.73-.59-3.82.23-1.03.77-1.45 2.02-1.5 3.32v.79s4.84 3.74 5.99 3.59z" />
                </svg>
            ),
            description: 'الدفع عبر محفظة فودافون كاش',
            instruction: 'بعد تأكيد الطلب سترفع صورة الإيصال'
        },
        {
            value: 'instapay',
            label: 'إنستاباي (InstaPay)',
            icon: (
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8">
                    <path d="M12 2L4 7l2 1.5L12 5l6 3.5 2-1.5L12 2zm0 4.5l-6 3.5v7l6 3.5 6-3.5v-7l-6-3.5zm0 8.5l-4-2.33 4-2.33 4 2.33L12 15z" />
                </svg>
            ),
            description: 'التحويل الفوري عبر إنستاباي',
            instruction: 'بعد تأكيد الطلب سترفع صورة الإيصال'
        },
        {
            value: 'cash_on_delivery',
            label: 'الدفع عند الاستلام',
            icon: (
                <svg viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8">
                    <path d="M2 7v10h20V7H2zm18 8H4V9h16v6zm-8-5c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z" />
                </svg>
            ),
            description: 'ادفع نقداً عند استلام العقار',
            instruction: 'سيتم الدفع عند الاستلام'
        }
    ];

    const getIconColor = (value: PaymentMethod, isSelected: boolean) => {
        if (isSelected) return 'text-white';
        if (value === 'vodafone_cash') return 'text-red-600';
        if (value === 'instapay') return 'text-purple-600';
        return 'text-emerald-600';
    };

    const containerClasses = "bg-white/70 backdrop-blur-md border border-white/40 rounded-2xl p-6 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.05)]";

    return (
        <div className={containerClasses}>
            <h3 className="text-lg font-semibold mb-4">طريقة الدفع</h3>

            <div className="space-y-3">
                {paymentOptions.map((option) => {
                    const isSelected = selectedMethod === option.value;

                    return (
                        <div key={option.value} className="flex flex-col gap-2">
                            <label
                                className={`
                                    relative w-full text-right p-5 border rounded-2xl cursor-pointer transition-all duration-300
                                    ${isSelected
                                        ? 'border-blue-600 bg-blue-50/50 shadow-[0_0_0_4px_rgba(37,99,235,0.1)]'
                                        : 'border-gray-300/50 bg-white/50 hover:bg-white hover:border-gray-400 hover:-translate-y-0.5 hover:shadow-sm'
                                    }
                                `}
                            >
                                <input
                                    type="radio"
                                    name="payment_method"
                                    value={option.value}
                                    checked={isSelected}
                                    onChange={() => onMethodChange(option.value)}
                                    className="sr-only"
                                />

                                <div className="flex items-center gap-4">
                                    <div className={`
                                        w-14 h-14 flex items-center justify-center rounded-xl shadow-sm transition-all duration-300
                                        ${isSelected ? 'bg-white border-2 border-blue-500 shadow-md scale-105' : 'bg-white border border-gray-100'}
                                    `}>
                                        <div className="w-10 h-10 relative flex items-center justify-center drop-shadow-sm">
                                            <Image
                                                src={`/payments/${option.value === 'vodafone_cash' ? 'vodafone.svg' : option.value === 'instapay' ? 'instapay.svg' : 'cash.png'}`}
                                                alt={option.label}
                                                fill
                                                className="object-contain"
                                                unoptimized
                                            />
                                        </div>
                                    </div>
                                    <div className="flex-1 text-right">
                                        <div className="font-semibold text-gray-900">{option.label}</div>
                                        <div className="text-sm text-gray-500 mt-1">{option.description}</div>
                                    </div>
                                    <div className={`
                                        w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors duration-300 bg-white shrink-0
                                        ${isSelected ? 'border-blue-600' : 'border-gray-300'}
                                    `}>
                                        {isSelected && <div className="w-3 h-3 rounded-full bg-blue-600 animate-[scaleIn_0.2s_ease-out]"></div>}
                                    </div>
                                </div>
                            </label>

                            {/* Contextual instruction panel - simplified */}
                            {isSelected && (
                                <div className="mr-4 ml-4 mt-1 p-2 text-sm text-gray-600 animate-[fadeInDown_0.3s_ease-out] flex items-center gap-2">
                                    <span className="material-symbols-outlined text-sm">info</span>
                                    <p>{option.instruction}</p>
                                </div>
                            )}
                        </div>
                    );
                })}
            </div>

            <style jsx>{`
                @keyframes scaleIn {
                    from { transform: scale(0); opacity: 0; }
                    to { transform: scale(1); opacity: 1; }
                }
                @keyframes fadeInDown {
                    from { opacity: 0; transform: translateY(-5px); }
                    to { opacity: 1; transform: translateY(0); }
                }
            `}</style>
        </div>
    );
}
