'use client';

import React from 'react';

interface TenantFormProps {
    tenantName: string;
    tenantPhone: string;
    tenantEmail: string;
    onNameChange: (name: string) => void;
    onPhoneChange: (phone: string) => void;
    onEmailChange: (email: string) => void;
}

export default function TenantForm({
    tenantName,
    tenantPhone,
    tenantEmail,
    onNameChange,
    onPhoneChange,
    onEmailChange
}: TenantFormProps) {
    const containerClasses = "bg-white/70 backdrop-blur-md border border-white/40 rounded-2xl p-6 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.05)]";
    const labelClasses = "block font-bold text-sm text-gray-700 text-right mb-2";
    const inputClasses = "w-full px-4 py-3 bg-white/50 border border-gray-300/50 rounded-xl text-base text-right rtl color-gray-900 transition-all focus:outline-none focus:bg-white focus:border-blue-600 focus:ring-4 focus:ring-blue-600/10 hover:border-gray-400 hover:bg-white/80 placeholder-gray-400";

    return (
        <div className={containerClasses}>
            <h3 className="text-lg font-semibold mb-4">بيانات المستأجر</h3>

            <div className="space-y-4">
                {/* الاسم الكامل */}
                <div className="flex flex-col">
                    <label className={labelClasses} htmlFor="tenant-name">
                        الاسم الكامل <span className="text-red-500">*</span>
                    </label>
                    <input
                        id="tenant-name"
                        type="text"
                        value={tenantName}
                        onChange={(e) => onNameChange(e.target.value)}
                        className={inputClasses}
                        placeholder="أدخل اسمك الكامل"
                        autoComplete="name"
                        required
                    />
                </div>

                {/* رقم الهاتف */}
                <div className="flex flex-col">
                    <label className={labelClasses} htmlFor="tenant-phone">
                        رقم الهاتف <span className="text-red-500">*</span>
                    </label>
                    <input
                        id="tenant-phone"
                        type="tel"
                        inputMode="numeric"
                        value={tenantPhone}
                        onChange={(e) => onPhoneChange(e.target.value)}
                        className={inputClasses}
                        placeholder="01xxxxxxxxx"
                        pattern="^01[0-9]{9}$"
                        autoComplete="tel"
                        required
                    />
                    <p className="text-xs text-gray-500 mt-1 mr-1">
                        سنستخدم هذا الرقم للتواصل معك
                    </p>
                </div>

                {/* البريد الإلكتروني */}
                <div className="flex flex-col">
                    <label className={labelClasses} htmlFor="tenant-email">
                        البريد الإلكتروني (اختياري)
                    </label>
                    <input
                        id="tenant-email"
                        type="email"
                        value={tenantEmail}
                        onChange={(e) => onEmailChange(e.target.value)}
                        className={inputClasses}
                        placeholder="example@email.com"
                        autoComplete="email"
                    />
                </div>
            </div>
        </div>
    );
}
