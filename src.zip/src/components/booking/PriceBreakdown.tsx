'use client';

import React, { useState } from 'react';
import { RentalType } from '@/types';

interface PriceBreakdownProps {
    rentalType: RentalType;
    duration: number;
    pricePerUnit: number;
    basePrice: number;
    serviceFee: number;
    depositAmount?: number;
    totalAmount: number;
}

export default function PriceBreakdown({
    rentalType,
    duration,
    pricePerUnit,
    basePrice,
    serviceFee,
    depositAmount,
    totalAmount
}: PriceBreakdownProps) {
    const [isExpanded, setIsExpanded] = useState(false);

    const getUnitLabel = () => {
        switch (rentalType) {
            case 'daily':
                return duration === 1 ? 'ليلة' : duration === 2 ? 'ليلتان' : 'ليالي';
            case 'monthly':
                return duration === 1 ? 'شهر' : duration === 2 ? 'شهران' : 'أشهر';
            case 'seasonal':
                return 'أشهر';
            default:
                return '';
        }
    };

    const formatNumber = (num: number) => num.toLocaleString('ar-EG');

    return (
        <div className={`transition-all duration-300 text-right ${isExpanded
            ? 'bg-white/80 backdrop-blur-md border border-white/40 rounded-2xl p-4 shadow-sm mb-4 md:mb-0'
            : ''
            } md:bg-white/70 md:backdrop-blur-md md:border md:border-white/40 md:rounded-2xl md:p-6 md:shadow-[0_10px_15px_-3px_rgba(0,0,0,0.05)]`}>

            {/* Header / Mobile Toggle Button */}
            <div className={`flex items-center ${isExpanded ? 'justify-between mb-4' : 'justify-center'} md:justify-between md:mb-6`}>
                <h3 className={`text-lg font-semibold text-gray-900 ${isExpanded ? 'block' : 'hidden md:block'}`}>تفاصيل الفاتورة</h3>

                <button
                    onClick={() => setIsExpanded(!isExpanded)}
                    className={`md:hidden font-semibold flex items-center justify-center gap-1 transition-all ${isExpanded
                        ? 'text-xs text-gray-500 bg-gray-100/80 px-3 py-1.5 rounded-full hover:bg-gray-200'
                        : 'w-full text-sm text-blue-600 bg-transparent py-1.5 hover:text-blue-700'
                        }`}
                >
                    {isExpanded ? 'إخفاء التفاصيل' : 'عرض الفاتورة بالكامل'}
                    <span className={`transform transition-transform ${isExpanded ? 'rotate-180' : ''}`}>▼</span>
                </button>
            </div>

            <div className={`transition-all duration-300 ${isExpanded ? 'block pt-2' : 'hidden md:block'}`}>
                <div className="space-y-4">
                    {/* السعر الأساسي */}
                    <div className="flex justify-between items-center text-sm md:text-base">
                        <span className="text-gray-600">
                            {formatNumber(duration)} {getUnitLabel()} × {formatNumber(pricePerUnit)} ج.م
                        </span>
                        <span className="font-medium text-gray-900">
                            {formatNumber(basePrice)} ج.م
                        </span>
                    </div>

                    {/* رسوم الخدمة */}
                    <div className="flex justify-between items-center text-sm md:text-base">
                        <span className="text-gray-600">رسوم الخدمة (10%)</span>
                        <span className="font-medium text-gray-900">
                            {formatNumber(serviceFee)} ج.م
                        </span>
                    </div>

                    {/* التأمين (للإيجار الموسمي فقط) */}
                    {!!(depositAmount && depositAmount > 0) && (
                        <div className="bg-amber-50/80 backdrop-blur-sm border border-amber-200/60 rounded-xl p-3 mt-3">
                            <div className="flex justify-between items-start gap-4">
                                <div>
                                    <span className="text-gray-800 font-bold text-sm">تأمين قابل للاسترداد</span>
                                    <p className="text-xs text-gray-500 mt-1 leading-relaxed">
                                        سيتم استرداد التأمين عند نهاية الإيجار
                                    </p>
                                </div>
                                <span className="font-bold text-amber-700 whitespace-nowrap">
                                    {formatNumber(depositAmount)} ج.م
                                </span>
                            </div>
                        </div>
                    )}

                    {/* الفاصل */}
                    <div className="border-t border-gray-200/60 my-4"></div>
                </div>

                {/* المجموع الكلي */}
                <div className="bg-gradient-to-br from-blue-50 to-blue-100/50 rounded-xl p-4 md:p-5 border border-blue-100 flex justify-between items-center mt-4">
                    <span className="text-base md:text-lg font-bold text-gray-800">المجموع الكلي</span>
                    <span className="text-xl md:text-2xl font-black text-blue-700 drop-shadow-sm">
                        {formatNumber(totalAmount)} ج.م
                    </span>
                </div>
            </div>
        </div>
    );
}
