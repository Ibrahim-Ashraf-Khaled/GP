'use client';

import React from 'react';
import { RentalConfig } from '@/types';

interface DateSelectorProps {
    rentalConfig: RentalConfig;
    startDate: Date | null;
    endDate: Date | null;
    onStartDateChange: (date: Date) => void;
    onEndDateChange: (date: Date) => void;
    onMonthsChange?: (months: number) => void;
}

export default function DateSelector({
    rentalConfig,
    startDate,
    endDate,
    onStartDateChange,
    onEndDateChange,
    onMonthsChange
}: DateSelectorProps) {
    const { type, minDuration, maxDuration, seasonalConfig } = rentalConfig;

    const formatDate = (date: Date | null) => {
        if (!date) return '';
        const offset = date.getTimezoneOffset();
        const adjustedDate = new Date(date.getTime() - (offset * 60 * 1000));
        return adjustedDate.toISOString().split('T')[0];
    };

    const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.value) return;
        const date = new Date(e.target.value);
        onStartDateChange(date);

        // Reset endDate if it becomes invalid
        if (endDate && date > endDate) {
            onEndDateChange(date);
        }
    };

    const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (!e.target.value) return;
        const date = new Date(e.target.value);
        onEndDateChange(date);
    };

    const handleMonthsChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
        const months = parseInt(e.target.value);
        if (onMonthsChange) {
            onMonthsChange(months);
        }

        if (startDate) {
            const end = new Date(startDate);
            end.setMonth(end.getMonth() + months);
            onEndDateChange(end);
        }
    };

    const getMinStartDate = () => {
        const today = new Date();
        return formatDate(today);
    };

    const getMinEndDate = () => {
        if (!startDate) return getMinStartDate();
        const minEnd = new Date(startDate);

        if (type === 'daily') {
            minEnd.setDate(minEnd.getDate() + (minDuration || 1));
        } else if (type === 'monthly') {
            minEnd.setMonth(minEnd.getMonth() + (minDuration || 1));
        }

        return formatDate(minEnd);
    };

    const getDurationText = (nights: number) => {
        if (nights === 1) return 'ليلة واحدة';
        if (nights === 2) return 'ليلتان';
        if (nights >= 3 && nights <= 10) return `${nights} ليالي`;
        return `${nights} ليلة`;
    };

    const getMonthsText = (months: number) => {
        if (months === 1) return 'شهر واحد';
        if (months === 2) return 'شهران';
        if (months >= 3 && months <= 10) return `${months} أشهر`;
        return `${months} شهر`;
    };

    const baseInputClasses = "w-full px-4 py-3 bg-white/50 border border-gray-300/50 rounded-xl text-base text-right rtl color-gray-900 transition-all focus:outline-none focus:bg-white focus:border-blue-600 focus:ring-4 focus:ring-blue-600/10 hover:not(:disabled):border-gray-400 hover:not(:disabled):bg-white/80 disabled:bg-gray-100/50 disabled:cursor-not-allowed disabled:text-gray-400";
    const labelClasses = "block font-bold text-sm text-gray-700 text-right mb-2";
    const containerClasses = "bg-white/70 backdrop-blur-md border border-white/40 rounded-2xl p-6 shadow-[0_10px_15px_-3px_rgba(0,0,0,0.05)]";

    if (type === 'daily') {
        const nights = (startDate && endDate)
            ? Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
            : 0;

        return (
            <div className={containerClasses}>
                <h3 className="text-lg font-semibold mb-2">اختر مواعيد الإقامة</h3>
                <p className="text-sm text-gray-500 mb-4">الإيجار يحسب بالليلة الواحدة</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col">
                        <label className={labelClasses}>تاريخ الوصول</label>
                        <input
                            type="date"
                            value={formatDate(startDate)}
                            onChange={handleStartDateChange}
                            min={getMinStartDate()}
                            className={baseInputClasses}
                            required
                        />
                    </div>

                    <div className="flex flex-col">
                        <label className={labelClasses}>تاريخ المغادرة</label>
                        <input
                            type="date"
                            value={formatDate(endDate)}
                            onChange={handleEndDateChange}
                            min={getMinEndDate()}
                            className={baseInputClasses}
                            required
                            disabled={!startDate}
                        />
                    </div>
                </div>

                {startDate && endDate && nights > 0 && (
                    <div className="mt-6 px-6 py-4 bg-emerald-50/60 backdrop-blur-sm rounded-xl border border-emerald-200/50 flex items-center gap-3 text-emerald-800 font-semibold">
                        <span className="text-xl">📅</span>
                        <span>المدة: {getDurationText(nights)}</span>
                    </div>
                )}
            </div>
        );
    }

    if (type === 'monthly') {
        return (
            <div className={containerClasses}>
                <h3 className="text-lg font-semibold mb-2">اختر فترة الإيجار</h3>
                <p className="text-sm text-gray-500 mb-4">الإيجار يحسب بالشهور الكاملة</p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex flex-col">
                        <label className={labelClasses}>تاريخ البداية</label>
                        <input
                            type="date"
                            value={formatDate(startDate)}
                            onChange={handleStartDateChange}
                            min={getMinStartDate()}
                            className={baseInputClasses}
                            required
                        />
                    </div>

                    <div className="flex flex-col">
                        <label className={labelClasses}>عدد الأشهر</label>
                        <select
                            onChange={handleMonthsChange}
                            className={baseInputClasses}
                            required
                            disabled={!startDate}
                        >
                            <option value="">اختر المدة</option>
                            {Array.from({ length: maxDuration - minDuration + 1 }, (_, i) => minDuration + i).map(months => (
                                <option key={months} value={months}>
                                    {getMonthsText(months)}
                                </option>
                            ))}
                        </select>
                    </div>
                </div>

                {endDate && (
                    <div className="mt-6 px-6 py-4 bg-emerald-50/60 backdrop-blur-sm rounded-xl border border-emerald-200/50 flex items-center gap-3 text-emerald-800 font-semibold">
                        <span className="text-xl">📅</span>
                        <span>
                            الإيجار ينتهي في: {endDate.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' })}
                        </span>
                    </div>
                )}
            </div>
        );
    }

    if (type === 'seasonal') {
        return (
            <div className={containerClasses}>
                <h3 className="text-lg font-semibold mb-4">الفترة الدراسية</h3>

                <div className="flex flex-col gap-4">
                    <div className="flex gap-4 items-start p-4 bg-blue-100/50 border border-blue-300 rounded-xl">
                        <span className="text-2xl">🎓</span>
                        <div>
                            <h4 className="font-semibold text-gray-900">إيجار الفترة الدراسية الكاملة</h4>
                            <p className="text-sm text-gray-600 mt-1">
                                من سبتمبر إلى يونيو (10 أشهر)
                            </p>
                        </div>
                    </div>

                    {seasonalConfig?.requiresDeposit && (
                        <div className="flex gap-4 items-start p-4 bg-amber-50 border border-amber-300 rounded-xl">
                            <span className="text-2xl">⚠️</span>
                            <div>
                                <h4 className="font-semibold text-amber-800">تأمين مطلوب</h4>
                                <p className="text-sm text-amber-700/80 mt-1">
                                    سيتم استرداد التأمين عند نهاية الفترة وتسليم العقار
                                </p>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        );
    }

    return null;
}
